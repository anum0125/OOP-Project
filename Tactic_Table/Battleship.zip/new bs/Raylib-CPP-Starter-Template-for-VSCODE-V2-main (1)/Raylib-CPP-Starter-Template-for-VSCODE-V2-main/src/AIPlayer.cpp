#include "AIPlayer.h"
#include <cstdlib>

void AIPlayer::SetupShips() {
    grid.PlaceAllShips();
}

Vector2 AIPlayer::GetRandomMove() {
    return { (float)(rand() % Grid::GRID_SIZE), (float)(rand() % Grid::GRID_SIZE) };
}

bool AIPlayer::Attack(Grid& enemyGrid) {
    for (int attempts = 0; attempts < 100; attempts++) {
        Vector2 move = GetRandomMove();
        if (!enemyGrid.IsCellAlreadyShot(move)) {
            bool hit;
            enemyGrid.Attack(move, hit);
            return true;
        }
    }
    return false;
}