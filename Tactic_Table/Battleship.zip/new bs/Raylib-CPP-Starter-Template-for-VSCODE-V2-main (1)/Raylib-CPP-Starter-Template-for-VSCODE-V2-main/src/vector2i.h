#ifndef VECTOR2I_H
#define VECTOR2I_H

struct Vector2i {
    int x, y;
};

#endif // VECTOR2I_H
