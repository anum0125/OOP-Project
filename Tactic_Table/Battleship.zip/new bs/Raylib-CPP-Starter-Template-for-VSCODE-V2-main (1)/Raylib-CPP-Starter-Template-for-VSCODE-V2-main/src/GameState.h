#ifndef GAMESTATE_H
#define GAMESTATE_H

enum GameState { PLACING, PLAYING, FINISHED };

#endif // GAMESTATE_H
