#pragma once
#include "Grid.h"

class Player {
public:
    Grid grid;
    void SetupShips();
    bool Attack(Grid& enemyGrid, Vector2 cell);
};

