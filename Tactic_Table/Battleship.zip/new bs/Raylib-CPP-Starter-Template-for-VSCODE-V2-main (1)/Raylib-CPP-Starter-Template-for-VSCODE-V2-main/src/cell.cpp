#include "Cell.h"
#include "C:\raylib\raylib\src\raylib.h"

Cell::Cell() {}

Cell::Cell(float x, float y, float size) {
    rect = {x, y, size, size};
}

void Cell::Draw() {
    DrawRectangleLinesEx(rect, 2, DARKGRAY);
    if (isHit) {
        if (hasShip) DrawRectangleRec(rect, RED);
        else DrawRectangleRec(rect, LIGHTGRAY);
    }
}

bool Cell::IsClicked(Vector2 mouse) {
    return CheckCollisionPointRec(mouse, rect);
}
