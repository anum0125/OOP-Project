#pragma once
#include "C:\raylib\raylib\src\raylib.h"

class Ship {
public:
    Vector2 positions[5]; // Max size 5
    int size;
    int hits;

    Ship();
    void Initialize(Vector2 start, int size, bool horizontal);
    bool IsHit(Vector2 cell);
    bool IsSunk() const;
};