#pragma once
#include "Grid.h"

class AIPlayer {
public:
    Grid grid;
    void SetupShips();
    Vector2 GetRandomMove();
    bool Attack(Grid& enemyGrid);
};