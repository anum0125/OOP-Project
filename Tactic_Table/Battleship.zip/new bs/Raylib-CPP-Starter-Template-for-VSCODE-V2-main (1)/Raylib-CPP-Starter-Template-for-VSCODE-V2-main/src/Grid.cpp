#include "Grid.h"
#include <cstdlib>

Grid::Grid() : shipCount(0) {
    for (int y = 0; y < GRID_SIZE; y++)
        for (int x = 0; x < GRID_SIZE; x++)
            shots[y][x] = false;
}

bool Grid::CanPlace(Vector2 start, int size, bool horizontal) {
    for (int i = 0; i < size; i++) {
        int x = (int)start.x + (horizontal ? i : 0);
        int y = (int)start.y + (horizontal ? 0 : i);
        if (x < 0 || y < 0 || x >= GRID_SIZE || y >= GRID_SIZE)
            return false;
        for (int s = 0; s < shipCount; s++) {
            for (int j = 0; j < ships[s].size; j++) {
                if ((int)ships[s].positions[j].x == x && (int)ships[s].positions[j].y == y)
                    return false;
            }
        }
    }
    return true;
}

bool Grid::PlaceShip(int size) {
    for (int attempts = 0; attempts < 100; attempts++) {
        Vector2 start = { (float)(rand() % GRID_SIZE), (float)(rand() % GRID_SIZE) };
        bool horizontal = rand() % 2;
        if (CanPlace(start, size, horizontal)) {
            ships[shipCount].Initialize(start, size, horizontal);
            shipCount++;
            return true;
        }
    }
    return false;
}

void Grid::PlaceAllShips() {
    int shipSizes[MAX_SHIPS] = {5, 4, 3, 3, 2};
    for (int i = 0; i < MAX_SHIPS; i++) {
        PlaceShip(shipSizes[i]);
    }
}

bool Grid::Attack(Vector2 cell, bool& hit) {
    int x = (int)cell.x;
    int y = (int)cell.y;
    if (x < 0 || y < 0 || x >= GRID_SIZE || y >= GRID_SIZE || shots[y][x]) {
        hit = false;
        return false;
    }
    shots[y][x] = true;
    hit = false;
    for (int i = 0; i < shipCount; i++) {
        if (ships[i].IsHit(cell)) {
            hit = true;
            return true;
        }
    }
    return true;
}

bool Grid::AllShipsSunk() {
    for (int i = 0; i < shipCount; i++) {
        if (!ships[i].IsSunk())
            return false;
    }
    return true;
}

bool Grid::IsCellAlreadyShot(Vector2 cell) {
    return shots[(int)cell.y][(int)cell.x];
}
