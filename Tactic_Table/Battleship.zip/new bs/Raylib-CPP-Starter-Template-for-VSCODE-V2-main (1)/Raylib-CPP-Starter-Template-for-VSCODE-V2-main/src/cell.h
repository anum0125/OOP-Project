#ifndef CELL_H
#define CELL_H

#include "C:\raylib\raylib\src\raylib.h"

struct Cell {
    Rectangle rect;
    bool hasShip = false;
    bool isHit = false;

    Cell();
    Cell(float x, float y, float size);
    void Draw();
    bool IsClicked(Vector2 mouse);
};

#endif // CELL_H
