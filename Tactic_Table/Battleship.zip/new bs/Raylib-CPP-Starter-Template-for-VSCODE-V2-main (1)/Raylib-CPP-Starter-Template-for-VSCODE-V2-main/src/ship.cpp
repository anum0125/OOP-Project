#include "Ship.h"

Ship::Ship() : size(0), hits(0) {}

void Ship::Initialize(Vector2 start, int size, bool horizontal) {
    this->size = size;
    this->hits = 0;
    for (int i = 0; i < size; i++) {
        positions[i].x = start.x + (horizontal ? i : 0);
        positions[i].y = start.y + (horizontal ? 0 : i);
    }
}

bool Ship::IsHit(Vector2 cell) {
    for (int i = 0; i < size; i++) {
        if ((int)positions[i].x == (int)cell.x && (int)positions[i].y == (int)cell.y) {
            hits++;
            return true;
        }
    }
    return false;
}

bool Ship::IsSunk() const {
    return hits >= size;
}