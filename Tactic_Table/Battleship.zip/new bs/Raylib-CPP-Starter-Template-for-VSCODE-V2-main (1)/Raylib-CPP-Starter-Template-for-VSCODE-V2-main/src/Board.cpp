#include "Board.h"
#include "raylib.h"

Board::Board(float offsetX, float offsetY) {
    offset = { offsetX, offsetY };
    for (int r = 0; r < gridSize; ++r)
        for (int c = 0; c < gridSize; ++c)
            grid[r][c] = new Cell(offsetX + c * cellSize, offsetY + r * cellSize, cellSize);
}

Board::~Board() {
    for (int r = 0; r < gridSize; ++r)
        for (int c = 0; c < gridSize; ++c)
            delete grid[r][c];
}

void Board::Draw(bool hideShips) {
    for (int r = 0; r < gridSize; ++r)
        for (int c = 0; c < gridSize; ++c) {
            grid[r][c]->Draw();
            if (grid[r][c]->hasShip && !hideShips && !grid[r][c]->isHit)
                DrawRectangleRec(grid[r][c]->rect, BLUE);
        }
}

std::pair<int, int> Board::GetCellIndex(Vector2 mouse) {
    for (int r = 0; r < gridSize; ++r)
        for (int c = 0; c < gridSize; ++c)
            if (grid[r][c]->IsClicked(mouse))
                return { r, c };
    return { -1, -1 };
}

bool Board::PlaceShip(int row, int col, int size, bool horizontal) {
    if (shipCount >= maxShips) return false;
    if (horizontal && col + size > gridSize) return false;
    if (!horizontal && row + size > gridSize) return false;

    for (int i = 0; i < size; ++i) {
        int r = row + (horizontal ? 0 : i);
        int c = col + (horizontal ? i : 0);
        if (grid[r][c]->hasShip) return false;
    }

    Ship ship(size);
    for (int i = 0; i < size; ++i) {
        int r = row + (horizontal ? 0 : i);
        int c = col + (horizontal ? i : 0);
        grid[r][c]->hasShip = true;
        ship.positions[i] = { c, r };
        ship.posCount++;
    }
    ships[shipCount++] = ship;
    return true;
}

bool Board::Attack(int row, int col) {
    if (grid[row][col]->isHit) return false;
    grid[row][col]->isHit = true;

    for (int i = 0; i < shipCount; ++i) {
        if (ships[i].Occupies(row, col)) {
            ships[i].RegisterHit();
            return true;
        }
    }
    return false;
}

bool Board::AllShipsSunk() {
    for (int i = 0; i < shipCount; ++i)
        if (!ships[i].IsSunk()) return false;
    return true;
}
