#include "C:\raylib\raylib\src\raylib.h"
#include "Player.h"
#include "AIPlayer.h"

const int CELL_SIZE = 40;
const int OFFSET = 50;

int main() {
    InitWindow(1000, 600, "Battleship - Human vs AI");
    SetTargetFPS(60);

    Player human;
    AIPlayer ai;

    human.SetupShips();
    ai.SetupShips();

    bool humanTurn = true;
    bool gameOver = false;
    const char* winner = nullptr;

    while (!WindowShouldClose()) {
        BeginDrawing();
        ClearBackground(RAYWHITE);

        // Draw grids
        for (int y = 0; y < Grid::GRID_SIZE; y++) {
            for (int x = 0; x < Grid::GRID_SIZE; x++) {
                // Human grid
                DrawRectangleLines(OFFSET + x * CELL_SIZE, OFFSET + y * CELL_SIZE, CELL_SIZE, CELL_SIZE, BLACK);
                // AI grid (offset to the right)
                DrawRectangleLines(OFFSET + 500 + x * CELL_SIZE, OFFSET + y * CELL_SIZE, CELL_SIZE, CELL_SIZE, BLACK);
            }
        }

        // Game Logic
        if (!gameOver) {
            if (humanTurn && IsMouseButtonPressed(MOUSE_LEFT_BUTTON)) {
                Vector2 mouse = GetMousePosition();
                int cellX = (mouse.x - OFFSET - 500) / CELL_SIZE;
                int cellY = (mouse.y - OFFSET) / CELL_SIZE;

                if (cellX >= 0 && cellX < Grid::GRID_SIZE && cellY >= 0 && cellY < Grid::GRID_SIZE) {
                    Vector2 attackCell = { (float)cellX, (float)cellY };
                    bool hit;
                    if (!ai.grid.IsCellAlreadyShot(attackCell)) {
                        human.Attack(ai.grid, attackCell);
                        if (ai.grid.AllShipsSunk()) {
                            gameOver = true;
                            winner = "Human Wins!";
                        } else {
                            humanTurn = false;
                        }
                    }
                }
            } else if (!humanTurn) {
                bool validMove = false;
                while (!validMove) {
                    validMove = ai.Attack(human.grid);
                }
                if (human.grid.AllShipsSunk()) {
                    gameOver = true;
                    winner = "AI Wins!";
                } else {
                    humanTurn = true;
                }
            }
        }

        // Draw outcome
        if (gameOver) {
            DrawText(winner, 400, 550, 30, RED);
        }

        EndDrawing();
    }

    CloseWindow();
    return 0;
}
