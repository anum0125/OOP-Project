#pragma once
#include "Ship.h"

class Grid {
public:
    static const int GRID_SIZE = 10;
    static const int MAX_SHIPS = 5;

    Ship ships[MAX_SHIPS];
    int shipCount;
    bool shots[GRID_SIZE][GRID_SIZE];

    Grid();

    bool PlaceShip(int size);
    void PlaceAllShips();
    bool CanPlace(Vector2 start, int size, bool horizontal);
    bool Attack(Vector2 cell, bool& hit);
    bool AllShipsSunk();
    bool IsCellAlreadyShot(Vector2 cell);
};