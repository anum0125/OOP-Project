#ifndef BOARD_H
#define BOARD_H

#include "Cell.h"
#include "Ship.h"
#include "Vector2i.h"
#include<utility>
#include "constants.h"

class Board {
public:
    Vector2 offset;
    Cell* grid[gridSize][gridSize];
    Ship ships[maxShips];
    int shipCount = 0;

    Board(float offsetX, float offsetY);
    ~Board();

    void Draw(bool hideShips);
    std::pair<int, int> GetCellIndex(Vector2 mouse);
    bool PlaceShip(int row, int col, int size, bool horizontal);
    bool Attack(int row, int col);
    bool AllShipsSunk();
};

#endif // BOARD_H
