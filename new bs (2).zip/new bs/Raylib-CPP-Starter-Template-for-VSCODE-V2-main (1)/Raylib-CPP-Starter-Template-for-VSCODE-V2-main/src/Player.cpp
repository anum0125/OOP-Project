#include "Player.h"

void Player::SetupShips() {
    grid.PlaceAllShips();
}

bool Player::Attack(Grid& enemyGrid, Vector2 cell) {
    bool hit;
    return enemyGrid.Attack(cell, hit);
}
