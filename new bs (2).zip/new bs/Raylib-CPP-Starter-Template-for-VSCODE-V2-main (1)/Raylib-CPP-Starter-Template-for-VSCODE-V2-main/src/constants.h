#ifndef CONSTANTS_H
#define CONSTANTS_H

const int gridSize = 10;
const float cellSize = 40;
const int maxShips = 5;
const int shipSizes[] = {5, 4, 3, 3, 2};

#endif // CONSTANTS_H
